package mx.edu.tesoem.itics.daniel.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class potencia extends AppCompatActivity {

    EditText num1;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_potencia);

        num1 = (EditText) findViewById(R.id.txtnum);
        resultado = (TextView) findViewById(R.id.lblresultado3);

    }

    public void potencia(View v){
        int a,r;
        a = Integer.parseInt(num1.getText().toString());
        r = a*a;
        resultado.setText(String.valueOf(r));

    }
}

