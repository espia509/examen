package mx.edu.tesoem.itics.daniel.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class segundapantalla extends AppCompatActivity implements View.OnClickListener {

    Button saludobtn, bot;
    EditText txtnombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_segundapantalla);

        bot = (Button) findViewById(R.id.button2);

        saludobtn = (Button) findViewById(R.id.button);
        saludobtn.setOnClickListener(this);

        txtnombre=(EditText) findViewById(R.id.editText);

}


    @Override
    public void onClick(View v) {
        Toast.makeText(this,"Bienvenido",Toast.LENGTH_SHORT).show();
        saludobtn.setEnabled(false);
    }

    public void saludomen(View v){
        Intent intent = new Intent(this, saludo.class);
        intent.putExtra("nom", txtnombre.getText().toString());
        startActivity(intent)
        ;
    }

    public void llamar(View v){
        Intent cargar = new Intent(this, operacionespantalla.class);
        startActivity(cargar);
    }
}
