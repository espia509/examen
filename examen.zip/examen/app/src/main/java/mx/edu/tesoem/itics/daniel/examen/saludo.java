package mx.edu.tesoem.itics.daniel.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class saludo extends AppCompatActivity {

    TextView saludo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        Bundle parametros = this.getIntent().getExtras();

        saludo = (TextView) findViewById(R.id.textView7);
        saludo.setText("Bienvenido"+parametros.getString("nom").toString());
    }
}
